import React from "react";
import { Box, Typography, Card, CardContent } from "@mui/material";

import icon1 from "../../src/assests/branding.svg";
import icon2 from "../../src/assests/development.svg";
import icon3 from "../../src/assests/app.svg";

const services = [
  {
    icon: icon1,
    title: "Overseas Recruitment",
    description:
      "Sourcing skilled, semi-skilled, and unskilled workers through a strong network of partners across Asia and Africa.",
    link: "#",
  },
  {
    icon: icon2,
    title: "Local Hiring (UAE)",
    description:
      "Providing manpower from within the UAE, including candidates with transferable visas and immediate availability.",
    link: "#",
  },
  {
    icon: icon3,
    title: "Executive Search & White-Collar Recruitment",
    description:
      "Identifying and recruiting professionals and management-level candidates across multiple sectors.",
    link: "#",
  },
  {
    icon: icon3,
    title: "Project-Based Manpower Supply",
    description:
      "Supplying workforce for short-term and long-term projects in construction, hospitality, logistics, oil & gas, and other industries.",
    link: "#",
  },
  {
    icon: icon2,
    title: "HR & Documentation Support",
    description:
      "Managing visa processing, onboarding, and compliance services to ensure a smooth hiring process.",
    link: "#",
  },
];

const Service = () => {
  const scrollRef = React.useRef(null);

  const scrollLeft = () => {
    scrollRef.current.scrollBy({ left: -350, behavior: "smooth" });
  };

  const scrollRight = () => {
    scrollRef.current.scrollBy({ left: 350, behavior: "smooth" });
  };

  const arrowBtnStyle = {
    padding: "12px 20px",
    fontSize: "22px",
    borderRadius: "50%",
    cursor: "pointer",
    border: "none",
    background: "#ffffff",
    boxShadow: "0 4px 14px rgba(0,0,0,0.2)",
  };

  return (
    <Box
      sx={{
        position: "relative",
        py: 8,
        backgroundColor: "#e3f0fc",
        overflow: "hidden",
      }}
    >
      {/* Main Container */}
      <Box
        sx={{
          maxWidth: 1200,
          mx: "auto",
          position: "relative",
          px: { xs: 2, sm: 3, md: 4 }, // Added horizontal padding for container
        }}
      >
        {/* Heading */}
        <Box textAlign="center" mb={4}>
          <Typography
            sx={{
              fontWeight: 700,
              fontSize: "40px",
              lineHeight: "52px",
              color: "#18326a",
            }}
          >
            Our Services
          </Typography>
        </Box>

        {/* LEFT ARROW - Positioned relative to container with responsive positioning */}
        <Box
          sx={{
            position: "absolute",
            top: "55%",
            left: { xs: "10px", sm: "15px", md: "20px", lg: "10px" }, // Responsive left positioning
            transform: "translateY(-50%)",
            zIndex: 10,
          }}
        >
          <button onClick={scrollLeft} style={arrowBtnStyle}>
            ←
          </button>
        </Box>

        {/* RIGHT ARROW - Positioned relative to container with responsive positioning */}
        <Box
          sx={{
            position: "absolute",
            top: "55%",
            right: { xs: "10px", sm: "15px", md: "20px", lg: "10px" }, // Responsive right positioning
            transform: "translateY(-50%)",
            zIndex: 10,
          }}
        >
          <button onClick={scrollRight} style={arrowBtnStyle}>
            →
          </button>
        </Box>

        {/* Horizontal Scroll Cards */}
        <Box
          sx={{
            display: "flex",
            gap: 3,
            overflowX: "hidden",
            scrollBehavior: "smooth",
            py: 2,
            // Added padding to ensure cards don't touch arrows on smaller screens
            px: { xs: 1, sm: 0 },
          }}
          ref={scrollRef}
        >
          {services.map((service, index) => (
            <Card
              key={index}
              sx={{
                minWidth: "280px",
                maxWidth: "280px",
                borderRadius: "5px",
                background: "#fff",
                textAlign: "center",
                flexShrink: 0,
                boxShadow: "0 6px 18px rgba(0,0,0,0.15)",
              }}
            >
              <Box
                component="img"
                src={service.icon}
                alt="icon"
                sx={{
                  width: 85,
                  height: 90,
                  marginY: 2.5,
                }}
              />

              <CardContent sx={{ px: 2, pb: 2 }}>
                <Typography
                  variant="h6"
                  sx={{
                    fontSize: "18px",
                    fontWeight: 600,
                    color: "#050748",
                  }}
                >
                  {service.title}
                </Typography>

                <Typography
                  sx={{
                    fontSize: "15px",
                    color: "#6a6a8e",
                    width: 240,
                    mx: "auto",
                    my: 1.5,
                  }}
                >
                  {service.description}
                </Typography>

                <Typography
                  component="a"
                  href={service.link}
                  sx={{
                    textDecoration: "none",
                    color: "#6a6a8e",
                    fontSize: "16px",
                    fontWeight: 600,
                    "&:hover": { color: "#003b5c" },
                  }}
                >
                  Learn More &gt;
                </Typography>
              </CardContent>
            </Card>
          ))}
        </Box>
      </Box>
    </Box>
  );
};

export default Service;