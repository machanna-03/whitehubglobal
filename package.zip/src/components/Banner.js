import React from "react";
import { Box, Button, Grid, Typography, Paper } from "@mui/material";
import PhoneIcon from "@mui/icons-material/Phone";
import EmailIcon from "@mui/icons-material/Email";
import AccessTimeIcon from "@mui/icons-material/AccessTime";

import heroImg from "../../src/assests/How-Do-You-Determine-If-a-Strategic-Priority-Is-Robust-11.png";

const PRIMARY = "#409bbeff";

function Banner() {
  return (
    <Box sx={{ position: "relative", pb: { xs: 16, md: 20 } }}>
      {/* HERO */}
      <Box
        sx={{
          position: "relative",
          backgroundImage: `url(${heroImg})`,
          backgroundSize: "cover",
          height: { xs: "300px", md: "400px" },
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          py: { xs: 8, md: 14 },
          px: { xs: 3, md: 4 },
          color: "#fff",
          zIndex: 1, // Add this
        }}
      >
        {/* Overlay */}
        <Box
          sx={{
            position: "absolute",
            inset: 0,
            background: "rgba(0, 0, 0, 0.7)",
            zIndex: 1, // Add this
          }}
        />

        {/* RIGHT ALIGNED CONTENT */}
        <Box
          sx={{
            position: "relative",
            zIndex: 2, // Keep this higher than overlay
            maxWidth: "400px",
            ml: "auto",
          }}
        >
          <Typography
            sx={{
              fontSize: { xs: "16px", md: "32px" },
              fontWeight: 600,
              opacity: 0.9,
              lineHeight: "1.2em",
              fontFamily: "Quicksand, sans-serif",
              mb: 1,
              letterSpacing: "0.5px",
            }}
          >
            Trusted Manpower Supply Across the Globe
          </Typography>

          <Typography
            sx={{
              mt: 2,
              fontSize: { xs: "14px", md: "18px" },
              maxWidth: "680px",
              ml: "auto",
              lineHeight: 1.6,
              opacity: 0.95,
              color: "#dfdfdff1",
            }}
          >
            We bring together industry experts to deliver reliable, efficient,
            and professional recruitment solutions. With strong UAE market
            knowledge and global sourcing strategies, we provide both local and
            overseas manpower.
          </Typography>

          {/* BUTTONS → RIGHT SIDE */}
          <Box
            sx={{
              display: "flex",
              gap: 2,
              mt: 5,
              flexWrap: "wrap",
              justifyContent: "flex-end",
            }}
          >
            <Button
              variant="contained"
              sx={{
                px: 4,
                py: 1.2,
                fontSize: "15px",
                borderRadius: "40px",
                background: "#004767",
                fontWeight: 600,
                boxShadow: "0px 4px 12px rgba(21, 95, 124, 0.4)",
                ":hover": {
                  boxShadow: "0px 4px 15px rgba(9, 82, 110, 0.7)",
                },
              }}
            >
              Hire Top Talent
            </Button>

            <Button
              variant="outlined"
              sx={{
                px: 4,
                py: 1.6,
                fontSize: "16px",
                borderRadius: "40px",
                borderColor: "#fff",
                color: "#fff",
                fontWeight: 600,
                ":hover": {
                  background: "rgba(255,255,255,0.1)",
                  borderColor: "#fff",
                },
              }}
            >
              Find A Job
            </Button>
          </Box>
        </Box>
      </Box>

      {/* CLASSIC FLOATING CONTACT CARDS */}
      <Grid
        container
        spacing={3}
        sx={{
          position: "absolute",
          top: { xs: "52%", md: "70%" },
          left: "50%",
          transform: "translateX(-50%)",
          width: { xs: "92%", md: "80%" },
          zIndex: 3, // Increase this to bring cards to front
        }}
      >
        {[
          {
            icon: <PhoneIcon sx={{ color: "#003b5c", fontSize: 30 }} />,
            title: "Speak To Our Experts",
            subtitle: "+91 9XXXX XXXXXX",
          },
          {
            icon: <EmailIcon sx={{ color: "#003b5c", fontSize: 30 }} />,
            title: "Send Us A Mail",
            subtitle: "whitehub@gmail.com",
          },
          {
            icon: <AccessTimeIcon sx={{ color: "#003b5c", fontSize: 30 }} />,
            title: "Our Operating Hours",
            subtitle: "Mon–Sat, 9am–6pm",
          },
        ].map((item, index) => (
          <Grid item xs={12} md={4} key={index}>
            <Paper
              elevation={0} 
              sx={{
                p: 3,
                borderRadius: "15px 15px 0 0",
                display: "flex",
                alignItems: "center",
                gap: 2,
                background: "#fff",
                position: "relative",
                WebkitMaskImage: "none", 
              }}
            >
              {/* ICON CIRCLE */}
              <Box
                sx={{
                  width: 70,
                  height: 70,
                  borderRadius: "50%",
                  background: "#eff5fa",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                {item.icon}
              </Box>

              {/* TEXT */}
              <Box>
                <Typography
                  sx={{
                    fontSize: "20px",
                    fontWeight: 700,
                    color: "#0d3150",
                  }}
                >
                  {item.title}
                </Typography>

                <Typography
                  sx={{
                    fontSize: "16px",
                    mt: 0.8,
                    color: "#4d4d4d",
                  }}
                >
                  {item.subtitle}
                </Typography>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}

export default Banner;