import React from "react";

import Service from "../../Service";
import Consultant from "./Consultant";
import Navbar from "../../common/Navbar";
import Header from "../../common/Header";
import Footer from "../../common/Footer";
import ServicesBanner from "./ServicesBanner";
import Hero from "./Hero";

const ServiceHomepage = () => {
  return (
    <div>
      <Navbar />
      <Header />
      <ServicesBanner />
      <Service />
      <Hero />
      <Consultant />

      <Footer />
    </div>
  );
};

export default ServiceHomepage;
